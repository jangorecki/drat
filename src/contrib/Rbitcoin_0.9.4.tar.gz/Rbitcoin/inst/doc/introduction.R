## ----init, echo=FALSE----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", dev="svg")
suppressPackageStartupMessages(library(Rbitcoin))
Sys.setenv(TZ="UTC") # plot always in UTC
options("Rbitcoin.antiddos.sec"=5) # faster build vignette

## ----shinybtc, eval=FALSE------------------------------------------------
#  shiny::runGitHub("jangorecki/shinyBTC")

## ----market_currency_pair------------------------------------------------
market <- "kraken"
currency_pair <- c("BTC","EUR")

## ----ticker_api----------------------------------------------------------
ticker <- market.api.process(market, currency_pair, "ticker")
ticker

## ----trades_api----------------------------------------------------------
trades <- market.api.process(market,currency_pair,"trades")
trades[["trades"]][,tail(.SD,10)] # print only last 10 trades

## ----trades_plot, fig.width = 7, fig.height = 5--------------------------
rbtc.plot(trades)

## ----order_book_api, fig.width = 7, fig.height = 5-----------------------
order_book <- market.api.process(market,currency_pair,"order_book")
rbtc.plot(order_book)

## ----order_book_print----------------------------------------------------
order_book[["asks"]][,head(.SD,10)] # print only first 10 asks

## ----wallet_api, eval=FALSE----------------------------------------------
#  wallet <- market.api.process(market, action = "wallet", key = "", secret = "")
#  wallet[["wallet"]] # print currencies and their amount in the wallet

## ----place_limit_order_api, eval=FALSE-----------------------------------
#  place_limit_order <- market.api.process(market, currency_pair, action = "place_limit_order",
#                                          req = list(type = "buy",
#                                                     price = 500,
#                                                     amount = 0.15)
#                                          key = "", secret = "")

## ----open_orders_api, eval=FALSE-----------------------------------------
#  open_orders <- market.api.process(market, action = "open_orders", key = "", secret = "")

## ----cancel_order_api, eval=FALSE----------------------------------------
#  cancel_order <- market.api.process(market, action = "cancel_order",
#                                     req = list(oid = "")
#                                     key = "", secret = "")

## ----api.dict------------------------------------------------------------
api.dict <- getOption("Rbitcoin.api.dict")
api.dict[!is.na(base), .(market, currency_pair = paste0(base,quote))][,unique(.SD)]

## ----to_from_api---------------------------------------------------------
fromBTC(1) # current BTCUSD price
toBTC(150, "GBP") # convert 150 GBP to BTC

## ----blockchain_api------------------------------------------------------
# some first wallets btc address details
addr <- blockchain.api.process('1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa')
str(addr)
# Rbitcoin donations btc address total received
blockchain.api.process('15Mb2QcgF3XDMeVn6M7oCG6CQLw4mkedDi')[["total_received"]]
# some transaction details
tx <- blockchain.api.process('e5c4de1c70cb6d60db53410e871e9cab6a0ba75404360bf4cda1b993e58d45f8')
str(tx, max.level=1)

## ----wallet_manager_exec, eval=FALSE-------------------------------------
#  # example market.sources
#  market.sources <- list(
#    "john smith" = list(market='kraken', key='', secret=''),
#    "jane smith" = list(market='kraken', key='', secret=''),
#    "john smith" = list(market='btce', key='', secret=''),
#    "jane smith" = list(market='btce', key='', secret='')
#  )
#  # example blockchain.sources
#  blockchain.sources <- list(
#    "john smith" = list(address='')
#  )
#  # example manual.sources
#  manual.sources <- list(
#    "john smith" = list(location='bitfinex', location_type='market',
#                        currency=c('BTC','USD'), amount=c(0.4,0)),
#    "john smith" = list(location='fidor', location_type='bank',
#                        currency=c('EUR','USD'), amount=c(20,0)),
#    "jane smith" = list(location='fidor', location_type='bank',
#                        currency=c('EUR','GBP'), amount=c(10,105))
#  )
#  # execute
#  wallet_dt <- wallet_manager(
#    market.sources = market.sources,
#    blockchain.sources = blockchain.sources,
#    manual.sources = manual.sources,
#    value_currency = 'USD', # your target currency
#    rate_priority = c('bitstamp','kraken','hitbtc','btce','bitmarket'), # value rates source priority
#    archive_write = TRUE # by default FALSE, read ?wallet_manager
#  )

## ----populate_wallet_dt, echo=FALSE--------------------------------------
full_wallet_dt <- structure(
  list(wallet_id = c(1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L,1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L, 1396310400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1398902400L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1401580800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1404172800L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1406851200L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L, 1409529600L),
    currency = c("BTC", "BTC", "BTC", "BTC", "BTC", "EUR", "EUR", "EUR", "EUR", "GBP", "LTC", "LTC", "LTC", "USD", "USD", "USD", "USD", "USD", "BTC", "BTC", "BTC", "BTC", "BTC", "EUR", "EUR", "EUR", "EUR", "GBP", "LTC", "LTC", "LTC", "USD", "USD", "USD", "USD", "USD", "BTC", "BTC", "BTC", "BTC", "BTC", "EUR", "EUR", "EUR", "EUR", "GBP", "LTC", "LTC", "LTC", "USD", "USD", "USD", "USD", "USD", "BTC", "BTC", "BTC", "BTC", "BTC", "EUR", "EUR", "EUR", "EUR", "GBP", "LTC", "LTC", "LTC", "USD", "USD", "USD", "USD", "USD", "BTC", "BTC", "BTC", "BTC", "BTC", "EUR", "EUR", "EUR", "EUR", "GBP", "LTC", "LTC", "LTC", "USD", "USD", "USD", "USD", "USD", "BTC", "BTC", "BTC", "BTC", "BTC", "EUR", "EUR", "EUR", "EUR", "GBP", "LTC", "LTC", "LTC", "USD", "USD", "USD", "USD", "USD"),
    currency_type = c("crypto", "crypto", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat", "crypto", "crypto", "crypto", "fiat", "fiat", "fiat", "fiat", "fiat"),
    auth = c("john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "jane smith", "john smith", "jane smith", "jane smith", "john smith", "john smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "jane smith", "john smith", "jane smith", "jane smith", "john smith", "john smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "jane smith", "john smith", "jane smith", "jane smith", "john smith", "john smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "jane smith", "john smith", "jane smith", "jane smith", "john smith", "john smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "jane smith", "john smith", "jane smith", "jane smith", "john smith", "john smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "john smith", "john smith", "jane smith", "jane smith", "john smith", "jane smith", "jane smith", "john smith", "john smith", "john smith", "john smith", "jane smith"),
    timestamp = structure(c(1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1396310400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1398902400, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1401580800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1404172800, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1406851200, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600, 1409529600), class = c("POSIXct", "POSIXt"), tzone = "UTC"),
    location = c("bitfinex", "kraken", "kraken", "btce", "15Mb2QcgF3XDMeVn6M7oCG6CQLw4mkedDi", "fidor", "fidor", "kraken", "kraken", "fidor", "kraken", "kraken", "btce", "fidor", "bitfinex", "kraken", "btce", "btce", "bitfinex", "kraken", "kraken", "btce", "15Mb2QcgF3XDMeVn6M7oCG6CQLw4mkedDi", "fidor", "fidor", "kraken", "kraken", "fidor", "kraken", "kraken", "btce", "fidor", "bitfinex", "kraken", "btce", "btce", "bitfinex", "kraken", "kraken", "btce", "15Mb2QcgF3XDMeVn6M7oCG6CQLw4mkedDi", "fidor", "fidor", "kraken", "kraken", "fidor", "kraken", "kraken", "btce", "fidor", "bitfinex", "kraken", "btce", "btce", "bitfinex", "kraken", "kraken", "btce", "15Mb2QcgF3XDMeVn6M7oCG6CQLw4mkedDi", "fidor", "fidor", "kraken", "kraken", "fidor", "kraken", "kraken", "btce", "fidor", "bitfinex", "kraken", "btce", "btce", "bitfinex", "kraken", "kraken", "btce", "15Mb2QcgF3XDMeVn6M7oCG6CQLw4mkedDi", "fidor", "fidor", "kraken", "kraken", "fidor", "kraken", "kraken", "btce", "fidor", "bitfinex", "kraken", "btce", "btce", "bitfinex", "kraken", "kraken", "btce", "15Mb2QcgF3XDMeVn6M7oCG6CQLw4mkedDi", "fidor", "fidor", "kraken", "kraken", "fidor", "kraken", "kraken", "btce", "fidor", "bitfinex", "kraken", "btce", "btce"),
    location_type = c("market", "market", "market", "market", "blockchain", "bank", "bank", "market", "market", "bank", "market", "market", "market", "bank", "market", "market", "market", "market", "market", "market", "market", "market", "blockchain", "bank", "bank", "market", "market", "bank", "market", "market", "market", "bank", "market", "market", "market", "market", "market", "market", "market", "market", "blockchain", "bank", "bank", "market", "market", "bank", "market", "market", "market", "bank", "market", "market", "market", "market", "market", "market", "market", "market", "blockchain", "bank", "bank", "market", "market", "bank", "market", "market", "market", "bank", "market", "market", "market", "market", "market", "market", "market", "market", "blockchain", "bank", "bank", "market", "market", "bank", "market", "market", "market", "bank", "market", "market", "market", "market", "market", "market", "market", "market", "blockchain", "bank", "bank", "market", "market", "bank", "market", "market", "market", "bank", "market", "market", "market", "market"),
    amount = c(0, 0.15, 0, 0, 0.1, 190, 130, 40, 80, 110, 0, 4, 1, 275, 25, 10, 30, 30, 0, 0.15, 0, 0, 0.1, 10, 0, 170, 260, 0, 0, 4, 1, 0, 100, 110, 130, 205, 0.22, 0.6, 0.45, 0.3, 0.1, 10, 10, 0, 40, 15, 10, 8, 10.5, 0, 0, 5, 15, 105, 0.12, 0.1, 0.45, 0.3, 0.7, 10, 20, 0, 40, 105, 10, 0, 18.5, 0, 0, 5, 0, 5, 0, 0.1, 0.2, 0, 0.15, 10, 20, 0, 140, 105, 10, 5, 0, 0, 400, 5, 225, 160, 0.4, 0.1, 0.6, 0.4, 0.55, 10, 20, 0, 0, 105, 10, 5, 35, 0, 0, 5, 50, 15),
    value_currency = c("USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD", "USD"),
    value_rate = c(478.98, 478.98, 478.98, 478.98, 478.98, 1.380905, 1.380905, 1.380905, 1.380905, 1.674109, 13.24, 13.24, 13.24, 1, 1, 1, 1, 1, 460.97, 460.97, 460.97, 460.97, 460.97, 1.373171, 1.373171, 1.373171, 1.373171, 1.68398, 11.02, 11.02, 11.02, 1, 1, 1, 1, 1, 630.99, 630.99, 630.99, 630.99, 630.99, 1.359912, 1.359912, 1.359912, 1.359912, 1.691485, 11.04, 11.04, 11.04, 1, 1, 1, 1, 1, 638.25, 638.25, 638.25, 638.25, 638.25, 1.353611, 1.353611, 1.353611, 1.353611, 1.70729, 7.83, 7.83, 7.83, 1, 1, 1, 1, 1, 589.59, 589.59, 589.59, 589.59, 589.59, 1.331674, 1.331674, 1.331674, 1.331674, 1.669659, 7.67, 7.67, 7.67, 1, 1, 1, 1, 1, 474.54, 474.54, 474.54, 474.54, 474.54, 1.288716, 1.288716, 1.288716, 1.288716, 1.629786, 4.7, 4.7, 4.7, 1, 1, 1, 1, 1),
    value = c(0, 71.847, 0, 0, 47.898, 262.37195, 179.51765, 55.2362, 110.4724, 184.15199, 0, 52.96, 13.24, 275, 25, 10, 30, 30, 0, 69.1455, 0, 0, 46.097, 13.73171, 0, 233.43907, 357.02446, 0, 0, 44.08, 11.02, 0, 100, 110, 130, 205, 138.8178, 378.594, 283.9455, 189.297, 63.099, 13.59912, 13.59912, 0, 54.39648, 25.372275, 110.4, 88.32, 115.92, 0, 0, 5, 15, 105, 76.59, 63.825, 287.2125, 191.475, 446.775, 13.53611, 27.07222, 0, 54.14444, 179.26545, 78.3, 0, 144.855, 0, 0, 5, 0, 5, 0, 58.959, 117.918, 0, 88.4385, 13.31674, 26.63348, 0, 186.43436, 175.314195, 76.7, 38.35, 0, 0, 400, 5, 225, 160, 189.816, 47.454, 284.724, 189.816, 260.997, 12.88716, 25.77432, 0, 0, 171.12753, 47, 23.5, 164.5, 0, 0, 5, 50, 15)),
  .Names = c("wallet_id", "currency", "currency_type", "auth", "timestamp", "location", "location_type", "amount", "value_currency", "value_rate", "value"),
  row.names = c(NA, -108L),
  class = c("data.table", "data.frame"),
  sorted = c("wallet_id", "currency")
)

## ----wallet_manager_recent_str, echo=c(2)--------------------------------
wallet_dt <- full_wallet_dt[wallet_id==max(wallet_id)] # ECHO OFF recent wallet from populated data
str(wallet_dt)

## ----wallet_manager_recent_plot, echo=c(1), fig.width = 7, fig.height = 7----
rbtc.plot(wallet_dt) # type="recent" due to `archive_read=FALSE` so: wallet_dt[,length(unique(wallet_id))]==1
wallet_dt <- full_wallet_dt # ECHO OFF full wallet archive from populated data

## ----wallet_manager_archive_load, eval=FALSE-----------------------------
#  # load archive only
#  wallet_dt <- wallet_manager(archive_write=FALSE, archive_read=TRUE)

## ----wallet_manager_archive_plot_value, eval=c(1), fig.width = 7, fig.height = 7----
rbtc.plot(wallet_dt) # type="value" due to `archive_read=TRUE`
# in case of poor legend scaling it might be better to export plot to file
svg("wallet_manager_value.svg")
rbtc.plot(wallet_dt)
dev.off()

