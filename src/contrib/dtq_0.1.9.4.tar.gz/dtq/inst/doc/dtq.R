## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(
  comment = "#",
  error = FALSE,
  tidy = FALSE,
  cache = FALSE,
  collapse = TRUE)
library(dtq)
invisible(dtl(purge=TRUE))

## ----dtl, message=FALSE--------------------------------------------------
library(dtq)
packageVersion("dtq")

# populate data
N=2e6; K=100
set.seed(1)
DT <- data.table(
  id1 = sample(sprintf("id%03d",1:K), N, TRUE),
  id2 = sample(sprintf("id%03d",1:K), N, TRUE),
  id3 = sample(sprintf("id%010d",1:(N/K)), N, TRUE),
  v1 =  sample(5, N, TRUE)
)

# data.table queries examples
{
  # single queries aggregations
  DT[, lapply(.SD, mean), keyby=id3, .SDcols="v1"]
  
  # single queries filtering
  DT[id1 %like% "id02"]
  
  # query chain
  DT[, .(v1=sum(v1)), .(id1, id2, id3)
     ][, .(v1=sum(v1)), .(id1, id2)
       ][, .(v1=sum(v1)), .(id1)
         ][, .(v1=sum(v1))]
  
  # nested functions
  d <- function() data.table(a=1:4, b=letters[1:4])
  f <- function() data.table(z = 1:5)
  d()[f()[2:3, z]]
  
  invisible()
}

# access data.table logs and print details
knitr::kable(dtl(print=TRUE))
# print queries log aggregated to chains
knitr::kable(dtl(chain=TRUE))

## ----dtq-----------------------------------------------------------------
dtl()$dtq[[2L]] # 2nd dt query
dtl()$dtq[[6L]] # 6th dt query

## ----read_only-----------------------------------------------------------
dtl(purge=TRUE)

DT <- data.table(a = 1L)
DT[, a := 2L]
print(DT)
  
DT <- data.table(a = 1L)
setattr(DT,"read.only",TRUE)
DT[, a := 2L]
print(DT)

knitr::kable(dtl(print=TRUE))

