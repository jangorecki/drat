pkgName = function(file){
    pkg = basename(file)
    pkgname = gsub("\\.tar\\..*$", "", pkg)
    strsplit(pkgname, "_", fixed=TRUE)[[1L]][1L]
}

gitinfo = function(){
    
    # try get git ref info from gitlab-ci env vars
    gitrefname = Sys.getenv("CI_BUILD_REF_NAME", unset = NA)
    gitref = Sys.getenv("CI_BUILD_REF", unset = NA)
    
    # try travis-ci git ref info if above not available
    if(is.na(gitrefname)) gitrefname = Sys.getenv("TRAVIS_BRANCH", unset = NA)
    if(is.na(gitref)) gitref = Sys.getenv("TRAVIS_COMMIT", unset = NA)
    
    # if none then make 0 length chars
    gitrefname = na.omit(gitrefname)
    gitref = na.omit(gitref)
    
    c(gitrefname = gitrefname, gitref = gitref)
}

insertHtml = function(repodir, repo.url = character(), repo.cran = FALSE, man = FALSE, git = character(), log = logical(), doc = FALSE){
    
    pkgdesc = file.path(repodir, "DESCRIPTION") # already should be copied here by insertManual, optionally as source of the build
    stopifnot(
        file.exists(pkgdesc),
        file.exists(repodir),
        is.character(repo.url),
        is.character(repo.cran) | is.logical(repo.cran),
        is.logical(man),
        is.character(git),
        is.logical(log),
        is.logical(doc)
    )
    
    # extract package metadata
    dcf = read.dcf(pkgdesc)
    pkg = unname(dcf[,"Package"])
    pkgtitle = if("Title" %in% colnames(dcf)) unname(dcf[,"Title"])
    pkgversion = if("Version" %in% colnames(dcf)) unname(dcf[,"Version"])
    upstream = if("URL" %in% colnames(dcf)) unname(dcf[,"URL"])
    additional.repo.url = if("Additional_repositories" %in% colnames(dcf)) strsplit(unname(dcf[,"Additional_repositories"]), split = ",", fixed = TRUE)[[1L]]
    # remove leading and trailing whitespaces
    additional.repo.url = gsub("^\\s+|\\s+$", "", additional.repo.url)
    
    # Additional_repositories are included into install string
    repo.url = c(repo.url, additional.repo.url)
    
    # cran can be logical for rstudio mirror or exact character address
    if(is.logical(repo.cran) && isTRUE(repo.cran)) repo.url = c(repo.url, "https://cran.rstudio.com")
    if(is.character(repo.cran) && length(repo.cran)) repo.url = c(repo.url, repo.cran)
    
    # build html file
    html = c(
        "<!DOCTYPE html>",
        "<html>",
        sprintf("<head><title>%s</title></head>", pkg),
        "<body>",
        sprintf("<h3>%s</h3>", pkg),
        sprintf("<h4>%s</h4>", pkgtitle),
        if(length(pkgversion)) sprintf("<p>Package version: %s</p>", pkgversion),
        if(length(git)){
            gitlabel = c(gitrefname = "Git branch:", gitref = "Git commit:")
            stopifnot(names(git) %in% names(gitlabel))
            sprintf("<p>%s</p>", paste(paste(gitlabel[names(git)], git), collapse = "<br/>"))
        },
        if(length(upstream)) sprintf('<p><a href="%s">upstream repo</a></p>', upstream),
        if(man | doc){
            sprintf("<p>%s</p>", paste(c('<a href="html/00Index.html">manual</a>'[man], '<a href="doc/index.html">doc</a>'[doc]), collapse="<br/>"))
        },
        if(length(repo.url)) c(
            "<p>Install from R:</p>",
            sprintf('<pre><code>install.packages("%s", repos = %s)</code></pre>', pkg, paste(deparse(repo.url, width.cutoff = 500), collapse=""))
        ),
        if(any(log)){
            logfiles = c("00install.out", "00check.log")
            stopifnot(length(log)==length(logfiles))
            sprintf("<p>%s</p>", paste(sprintf('<a href="%s">%s</a>', logfiles[log], logfiles[log]), collapse = "<br/>"))
        },
        "<br/>",
        sprintf("<p><small>generated at %s</small></p>", as.character(Sys.time())),
        "</body>",
        "</html>"
    )
    
    # write index.html
    html.path = file.path(repodir, "index.html")
    writeLines(html, html.path)
    
    TRUE
}

insertManual = function(file, repodir){
    
    # input check
    stopifnot(
        file.exists(file),
        file.exists(repodir)
    )
    
    # extract package name and type
    pkg = pkgName(file)
    pkgtype = identifyPackageType(file)
    
    # install to temp
    tmp.lib = tempdir()
    tmp.repo = file.path(tmp.lib, pkg)
    if(file.exists(tmp.repo)) unlink(tmp.repo, recursive = TRUE)
    on.exit(try(remove.packages(pkg, lib = tmp.lib), silent=TRUE))
    r = tryCatch(
        utils::install.packages(file, lib = tmp.lib, type = pkgtype, repos = NULL, quiet = TRUE, INSTALL_opts = c("--html")), # `utils::` to avoid RStudio issue
        error = function(e) e,
        warning = function(w) w
    )
    # stop on warning too
    if(inherits(r, "error") || inherits(r, "warning")) stop(sprintf("Installation of %s into temporary lib.loc '%s' failed with %s: %s.", pkg, tmp.lib, if(inherits(r, "error")) "error" else "warning", as.character(r$message)), call. = FALSE)
    
    # copy manual
    pkghtml = system.file("html", package = pkg, lib.loc = tmp.lib)
    repohtml = file.path(repodir, "html")
    if(file.exists(repohtml)) unlink(repohtml, recursive = TRUE)
    dir.create(repohtml, recursive = TRUE)
    # copy DESCRIPTION which is linked from manuals
    file.copy(system.file("DESCRIPTION", package = pkg, lib.loc = tmp.lib), repodir, overwrite = TRUE)
    
    # copy html manuals
    all(
        file.copy(list.files(pkghtml, full.names = TRUE), to = repohtml, recursive = TRUE)
    )
}

##' @title Generate R package artifacts
##' @description Generate basic html website with basic package info, includes html manuals, package installation string, links to check logs. Additionally \emph{CI} environment variables for git branch and git commit will be included if available.
##' @param file An R package in source or binary format.
##' @param repodir A local directory corresponding to the repository top-level directory.
##' @param repo.url character, url to be used in \emph{repos} argument in generated \code{install.packages} call for html website.
##' @param repo.cran logical or character, default FALSE, if TRUE it will append repository list with CRAN repo in generated \code{install.packages} call.
##' @return TRUE invisibly.
##' @examples
##' \dontrun{
##'   insertArtifacts(file = "drat_0.1.0.tar.gz",
##'                   repodir = "drat", 
##'                   repo.url = "https://eddelbuettel.github.io/drat")
##' }
##' @author Jan Gorecki
insertArtifacts = function(file = list.files(pattern = "*\\.tar\\.gz$"), repodir = "public", repo.url = character(), repo.cran = FALSE){
    
    rcheckdir = paste0(pkgName(file), ".Rcheck")
    if(!file.exists(repodir)) dir.create(repodir, recursive = TRUE)
    
    stopifnot(
        file.exists(file),
        file.exists(rcheckdir),
        file.exists(repodir)
    )

    # insertPackage
    drt = insertPackage(file = file, repodir = repodir)
    
    # insertManual
    man = insertManual(file = file, repodir = repodir)

    # git commit and ref from CI env vars
    git = gitinfo()
    
    # copy 00install.out, 00check.log
    log = file.copy(file.path(rcheckdir, c("00install.out", "00check.log")),
                    file.path(repodir, c("00install.out", "00check.log")),
                    overwrite = TRUE)
    
    # copy doc directory
    docs.build = file.path(rcheckdir, pkg = pkgName(file), "doc")
    doc = if(!file.exists(docs.build)) FALSE else {
        docs.path = file.path(repodir, "doc")
        if(file.exists(docs.path)) unlink(docs.path)
        dir.create(docs.path)
        all(file.copy(list.files(docs.build, full.names = TRUE), docs.path, overwrite = TRUE))
    }

    # insertHtml
    invisible(
        insertHtml(repodir = repodir, repo.url = repo.url, repo.cran = repo.cran, man = man, git = git, log = log, doc = doc)
    )
}
