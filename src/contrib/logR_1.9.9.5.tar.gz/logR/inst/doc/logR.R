## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(
  comment = "#",
  error = FALSE,
  tidy = FALSE,
  cache = FALSE,
  collapse = TRUE)

## ----connection, message=FALSE-------------------------------------------
library(logR)
library(RH2)
options("logR.db" = TRUE,
        "logR.conn" = dbConnect(H2(), "jdbc:h2:mem:"))

## ----schema--------------------------------------------------------------
logR_schema(vendor = "h2")

## ----usage_fun-----------------------------------------------------------
f_success <- function(x){
  x[,.(a=mean(a)),.(b)]
}
f_warning <- function(x){
  x[,.(a=log(a*(-1))),.(b)]
}
f_error <- function(x){
  x[,.(a=a+as.character(a)),.(b)]
}
f_double_warning <- function(){
  warning("warning A")
  r <- 5
  warning("warning B")
  r^2
}
f_nested_double_warning <- function(x){
  z <- f_double_warning()
  x[,.(a=mean(a+z)),.(b)]
}
f_warning_nested_double_warning <- function(x){
  z <- f_double_warning()
  r <- x[,.(a=mean(a+z)),.(b)]
  warning("warning C")
  r
}
f_wait <- function(x){
  Sys.sleep(0.0005)
  x
}

## ----usage_exec----------------------------------------------------------
dt <- data.table(a = rnorm(4), b = 1:2)

logR(f_success(dt))
logR(f_warning(dt),
     tag = "business_process2") # optional tag to log
logR(f_error(dt),
     tag = "business_process3",
     in_rows = nrow(dt)) # optional in_rows to log
logR(f_nested_double_warning(dt),
     tag = "business_process4",
     in_rows = nrow(dt))
logR(f_warning_nested_double_warning(dt),
     tag = "business_process5",
     in_rows = nrow(dt))

# proc.time vs nanotime
logR(f_wait(dt),
     tag = "nanotime on")
op <- options("logR.nano" = FALSE)
logR(f_wait(dt),
     tag = "nanotime force off")
options(op)

# log but not suppress exception
logR(f_warning_nested_double_warning(dt),
     silent = FALSE,
     tag = "business_process5")

## ----usage_view----------------------------------------------------------
# preview logs in R
dt <- logR_query()
str(dt)
knitr::kable(dt)
# preview logs in browser using shiny app
if(interactive()) logR_browser()

## ----watcher, results='hide'---------------------------------------------
watcher <- function(){
  dt <- logR_query()[is.na(status) & logr_start < Sys.time()-60*60]
  if(nrow(dt) > 0L) stop(paste("Unknown status detected by watcher, count:",nrow(dt)))
  invisible()
}
logR(watcher())

## ----disconnect, echo=FALSE, results='hide'------------------------------
invisible(dbDisconnect(getOption("logR.conn")))

